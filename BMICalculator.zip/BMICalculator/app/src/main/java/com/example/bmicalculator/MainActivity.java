package com.example.bmicalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText editTextWeight, editTextHeight, editTextHeight1;
    private TextView textViewResult;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextWeight = findViewById(R.id.editTextWeight);
        editTextHeight = findViewById(R.id.editTextHeight);
        editTextHeight1 = findViewById(R.id.editTextHeight1);
        textViewResult = findViewById(R.id.textViewResult);

        Button buttonCalculate = findViewById(R.id.buttonCalculate);
        buttonCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateBMI();
            }
        });
    }

    private void calculateBMI() {
        String weightStr = editTextWeight.getText().toString();
        String heightStr = editTextHeight.getText().toString();
        String heightStr1 = editTextHeight1.getText().toString();
        StringBuilder toastresult = new StringBuilder();

        if (!weightStr.isEmpty() && !heightStr.isEmpty()) {
            float weight = Float.parseFloat(weightStr);
            float height = Float.parseFloat(heightStr);
            float height1 = Float.parseFloat(heightStr1);

            float bmi = calculateBMIValue(weight, height, height1);
            String bmiStatus = getBMIStatus(bmi);

            String result = String.format("Your BMI: %.1f\n%s", bmi, bmiStatus);
            //textViewResult.setText(result);
            toastresult.append(result);
        } else {
            //textViewResult.setText("Please enter weight and height.");
            toastresult.append("Please enter weight and height.");
        }

        Context context = getApplicationContext();
        LayoutInflater layoutInflater = getLayoutInflater();
        View toastRoot = layoutInflater.inflate(R.layout.toast, null);
        TextView textView = toastRoot.findViewById(R.id.result);
        textView.setText(toastresult.toString());
        Toast toast = new Toast(context);
        toast.setView(toastRoot);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER, 0 ,375);
        toast.show();
    }

    private float calculateBMIValue(float weight, float height, float height1) {
        float totalinches = (height * 12) + height1;
        float heightMeters = (float) (totalinches * 0.0254);
        return weight / (heightMeters * heightMeters);
    }

    private String getBMIStatus(float bmi) {
        if (bmi < 18.5) {
            return "Underweight";
        } else if (bmi < 25) {
            return "Normal weight";
        } else if (bmi < 30) {
            return "Overweight";
        } else {
            return "Obese";
        }
    }

}
